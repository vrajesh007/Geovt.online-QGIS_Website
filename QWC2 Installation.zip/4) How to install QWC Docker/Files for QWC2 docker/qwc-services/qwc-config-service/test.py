import unittest

from tests.api_tests import *


if __name__ == '__main__':
    # run all imported test cases
    unittest.main()
