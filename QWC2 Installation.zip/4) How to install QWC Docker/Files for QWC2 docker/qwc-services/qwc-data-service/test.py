import unittest

# from tests.api_tests import *
from tests.feature_validation_tests import *
# from tests.feature_validation_tests_somap import *


if __name__ == '__main__':
    # run all imported test cases
    unittest.main()
